script(1, "Hello World").
script(2, "I am a rule-based, cognitive agent.").
script(3, "I have a simple purpose in life:").
script(4, "Print text that is part of my script.").
script(5, "For each sentence that is part of my script").
script(6, "I print text using a `printText' action.").
script(7, "I keep track of the number of lines").
script(8, "that I have printed so far by means of").
script(9, "a percept that is provided by the printing").
script(10, "environment that I am using.").
script(11, "Bye now, see you next time!"). 