:-dynamic associate/2.
:-dynamic ownId/1.

:-dynamic performGoTo/1.
:-dynamic performGoTo/2. 
:-dynamic performGoToBlock/1.
:-dynamic 	performGoToBlock/2.
:-dynamic  performPickUp/1.
:-dynamic performPutDown/0.
