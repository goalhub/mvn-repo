meeting(date(1, 02, 2010), time(12,00), duration(1,00), [jane, tarzan]).
