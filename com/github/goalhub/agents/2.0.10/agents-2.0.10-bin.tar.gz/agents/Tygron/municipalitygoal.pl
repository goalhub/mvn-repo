% insert your swi prolog code
offeredLand, soldLand.