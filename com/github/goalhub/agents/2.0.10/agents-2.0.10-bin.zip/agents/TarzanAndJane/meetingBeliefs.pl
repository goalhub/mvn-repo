% this is some appointment that is already in the calendar.
meeting(date(26, 01, 2010), time(12,30), duration(1,30), [jane, tarzan]).
