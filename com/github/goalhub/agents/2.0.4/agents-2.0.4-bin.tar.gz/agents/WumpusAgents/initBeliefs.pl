insideCave.
has(arrow).
wumpusIsAlive.
steps(0).
